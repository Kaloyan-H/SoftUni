﻿using System;
using System.Linq;

namespace _08.Threeuple
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] lineOne = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string[] lineTwo = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string[] lineThree = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            Threeuple<string, string, string> nameAddressTown = new Threeuple<string, string, string>(
                $"{lineOne[0]} {lineOne[1]}",
                lineOne[2],
                $"{lineOne[3]}{(lineOne.Length == 5 ? " " + lineOne[4] : String.Empty)}");

            Tuple<string, int, bool> nameBeerDrunk = new Tuple<string, int, bool>(
                lineTwo[0],
                int.Parse(lineTwo[1]),
                lineTwo[2] == "drunk");

            Tuple<string, double, string> nameBalanceBank = new Tuple<string, double,string>(
                lineThree[0],
                double.Parse(lineThree[1]),
                lineThree[2]);


            Console.WriteLine($"{nameAddressTown.Item1} -> {nameAddressTown.Item2} -> {nameAddressTown.Item3}");
            Console.WriteLine($"{nameBeerDrunk.Item1} -> {nameBeerDrunk.Item2} -> {nameBeerDrunk.Item3}");
            Console.WriteLine($"{nameBalanceBank.Item1} -> {nameBalanceBank.Item2} -> {nameBalanceBank.Item3}");
        }
    }
}
