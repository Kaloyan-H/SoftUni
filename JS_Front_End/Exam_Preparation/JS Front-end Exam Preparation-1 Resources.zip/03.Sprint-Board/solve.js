// TODO:
function attachEvents() {

}

attachEvents();